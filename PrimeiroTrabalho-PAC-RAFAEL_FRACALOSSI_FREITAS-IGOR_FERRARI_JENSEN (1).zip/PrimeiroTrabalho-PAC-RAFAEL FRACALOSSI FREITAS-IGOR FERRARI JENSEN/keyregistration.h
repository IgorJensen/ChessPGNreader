#include <iostream>
#include <conio.h>
#ifndef KEY_H
#define KEY_H

int keyregistration();

enum KEYS
{
    UP = 1,
    DOWN,
    LEFT,
    RIGHT,
    ENTER,
};

#endif